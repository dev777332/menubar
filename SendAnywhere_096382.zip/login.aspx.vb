﻿
Imports System.Data
Imports System.Data.SqlClient
Partial Class login
    Inherits System.Web.UI.Page

    Protected Sub btnLogin_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        Dim cn As New SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString)
        Dim cmd As New SqlCommand("select * from stud1 where username='" + txtusername.Text + "' and password='" + txtpassword.Text + "'", cn)
        Dim da As New SqlDataAdapter(cmd)
        Dim ds As New DataSet
        da.Fill(ds)

        If ds.Tables(0).Rows.Count = 1 Then
            Session("sid") = ds.Tables(0).Rows(0).Item(0).ToString
            Response.Redirect("updateProfile.aspx")
        Else
            lblError.Text = "Invalid username or password"
        End If
        GridView1.DataSource = ds.Tables(0)
        GridView1.DataBind()
    End Sub


End Class
