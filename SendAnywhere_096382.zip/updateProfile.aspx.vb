﻿Imports System.Data
Imports System.Data.SqlClient
Partial Class updateProfile
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load

        If Not Page.IsPostBack Then
            If Session("sid") Is Nothing Then
                Response.Redirect("login.aspx")
            Else
                Dim cn As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=D:\TYBCA837\ASP\SITE1\App_Data\d1.mdf;Integrated Security=True;User Instance=True")
                Dim cmd As New SqlCommand("select * from stud1 where sid=" & Session("sid") & "", cn)
                Dim da As New SqlDataAdapter(cmd)
                Dim ds As New DataSet
                da.Fill(ds)

                txtname.Text = ds.Tables(0).Rows(0).Item(1).ToString
                txtmobileno.Text = ds.Tables(0).Rows(0).Item(2).ToString
                txtcity.Text = ds.Tables(0).Rows(0).Item(3).ToString
                txtemail.Text = ds.Tables(0).Rows(0).Item(4).ToString
                txtusername.Text = ds.Tables(0).Rows(0).Item(5).ToString
            End If
        End If
        

    End Sub

    Protected Sub btnupdate_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnupdate.Click
        Dim con As New SqlConnection("Data Source=.\SQLEXPRESS;AttachDbFilename=D:\TYBCA837\ASP\SITE1\App_Data\d1.mdf;Integrated Security=True;User Instance=True")
        Dim q As String = "update stud1 set sname='" & txtname.Text & "',sphonenumber='" & txtmobileno.Text & "',city='" & txtcity.Text & "',semail='" & txtemail.Text & "',username='" & txtusername.Text & "',password='" & txtpass.Text & "' where sid=" & Session("sid") & ""
        Dim effect As Integer = 0
        con.Open()
        Dim cmd As New SqlCommand(q, con)
        effect = cmd.ExecuteNonQuery()
        con.Close()
        If (effect > 0) Then
            lblforError.Text = "Update Successful"
        Else
            lblforError.Text = "update Failed"
        End If
    End Sub

    Protected Sub btnDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Dim con As New SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings("ConnectionString").ConnectionString)
        Dim q As String = "delete from stud1 where sid=" & Session("sid") & ""
        Dim effect As Integer = 0
        con.Open()
        Dim cmd As New SqlCommand(q, con)
        effect = cmd.ExecuteNonQuery()
        con.Close()
        If (effect > 0) Then
            lblforError.Text = "Deleted Successful"
            Session.Abandon()
            Response.Redirect("login.aspx")
        Else
            lblforError.Text = "Deleting Failed"
        End If

    End Sub
End Class
